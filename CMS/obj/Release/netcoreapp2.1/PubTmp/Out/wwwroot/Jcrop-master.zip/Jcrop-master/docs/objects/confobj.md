---
title: ConfObj Object
lang: en-US
---

# `ConfObj` Object

#### Source Code

<<< @/build/js/confobj.js
